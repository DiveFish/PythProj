'''
Created on 26 Feb 2016

@author: kibs
'''

import os
import nltk
from nltk.corpus.reader.plaintext import PlaintextCorpusReader

print os.getcwd()

corpus_dir = 'project/WeeBit-TextOnly_Sample/'

weebit_sample = PlaintextCorpusReader(corpus_dir, ".*")
#print weebit_sample.fileids()

#print len(weebit_sample.fileids())

#print len(weebit_sample.sents())

weebit_ts = list()
'''
for sent in weebit_sample.sents():
    tagged_sent = nltk.pos_tag(sent)
    weebit_tagged_sents.append(tagged_sent)
'''   
#print weebit_tagged_sents

from TTR import TTR_tagged_sents
from pronoun_count import count_pronouns_corpus
from sent_feats import sent_length_average, word_length_average

print '"File","No. of Sentences","TTR","Avg Sentence Length","Avg Word Length","Pronoun Count"'
print '"BitGCSE"'
bitgcse_c = PlaintextCorpusReader(corpus_dir+'BitGCSE', ".*")

bitgcse_ts = list()

#get ttr of each txt
for file in bitgcse_c.fileids():
    bitgcse_txt_ts = list()
    for sent in bitgcse_c.sents(fileids=file):
        ts = nltk.pos_tag(sent)
        bitgcse_txt_ts.append(ts)
        bitgcse_ts.append(ts)
        weebit_ts.append(ts)
    print '"' + str(file) + '",' + str(len(bitgcse_c.sents(fileids=file))) + ',' + str(TTR_tagged_sents(bitgcse_txt_ts)) + ',' + str(sent_length_average(bitgcse_txt_ts)) + ',' + str(word_length_average(bitgcse_txt_ts)) + ',' + str(count_pronouns_corpus(bitgcse_txt_ts))
print '"BitGCSE",' + str(len(bitgcse_c.sents())) + ',' + str(TTR_tagged_sents(bitgcse_ts)) + ',' + str(sent_length_average(bitgcse_ts)) + ',' + str(word_length_average(bitgcse_ts)) + ',' + str(count_pronouns_corpus(bitgcse_ts))

bitks3_c = PlaintextCorpusReader(corpus_dir+'BitKS3', ".*")
#print len(bitgcse_sample.fileids())
bitks3_ts = list()

for file in bitks3_c.fileids():
    bitks3_txt_ts = list()
    for sent in bitks3_c.sents(fileids=file):
        ts = nltk.pos_tag(sent)
        bitks3_txt_ts.append(ts)
        bitks3_ts.append(ts)
        weebit_ts.append(ts)
    print '"' + str(file) + '",' + str(len(bitks3_c.sents(fileids=file))) + ',' + str(TTR_tagged_sents(bitks3_txt_ts)) + ',' + str(sent_length_average(bitks3_txt_ts)) + ',' + str(word_length_average(bitks3_txt_ts)) + ',' + str(count_pronouns_corpus(bitks3_txt_ts))
print '"BitKS3",' + str(len(bitks3_c.sents())) + ',' + str(TTR_tagged_sents(bitks3_ts)) + ',' + str(sent_length_average(bitks3_ts)) + ',' + str(word_length_average(bitks3_ts)) + ',' + str(count_pronouns_corpus(bitks3_ts))

print '"WRLevel4"'
wr4_c = PlaintextCorpusReader(corpus_dir+'WRLevel4', ".*")
wr4_ts = list()

for file in wr4_c.fileids():
    wr4_txt_ts = list()
    for sent in wr4_c.sents(fileids=file):
        ts = nltk.pos_tag(sent)
        wr4_txt_ts.append(ts)
        wr4_ts.append(ts)
        weebit_ts.append(ts)
    print '"' + str(file) + '",' + str(len(wr4_c.sents(fileids=file))) + ',' + str(TTR_tagged_sents(wr4_txt_ts)) + ',' + str(sent_length_average(wr4_txt_ts)) + ',' + str(word_length_average(wr4_txt_ts)) + ',' + str(count_pronouns_corpus(wr4_txt_ts))
print '"WRLevel4",' + str(len(wr4_c.sents())) + ',' + str(TTR_tagged_sents(wr4_ts)) + ',' + str(sent_length_average(wr4_ts)) + ',' + str(word_length_average(wr4_ts)) + ',' + str(count_pronouns_corpus(wr4_ts))

print '"WRLevel3"'
wr3_c = PlaintextCorpusReader(corpus_dir+'WRLevel3', ".*")
wr3_ts = list()

for file in wr3_c.fileids():
    wr3_txt_ts = list()
    for sent in wr3_c.sents(fileids=file):
        ts = nltk.pos_tag(sent)
        wr3_txt_ts.append(ts)
        wr3_ts.append(ts)
        weebit_ts.append(ts)
    print '"' + str(file) + '",' + str(len(wr3_c.sents(fileids=file))) + ',' + str(TTR_tagged_sents(wr3_txt_ts)) + ',' + str(sent_length_average(wr3_txt_ts)) + ',' + str(word_length_average(wr3_txt_ts)) + ',' + str(count_pronouns_corpus(wr3_txt_ts))
print '"WRLevel3",' + str(len(wr3_c.sents())) + ',' + str(TTR_tagged_sents(wr3_ts)) + ',' + str(sent_length_average(wr3_ts)) + ',' + str(word_length_average(wr3_ts)) + ',' + str(count_pronouns_corpus(wr3_ts))

print '"WRLevel2"'
wr2_c = PlaintextCorpusReader(corpus_dir+'WRLevel2', ".*")
wr2_ts = list()

for file in wr2_c.fileids():
    wr2_txt_ts = list()
    for sent in wr2_c.sents(fileids=file):
        ts = nltk.pos_tag(sent)
        wr2_txt_ts.append(ts)
        wr2_ts.append(ts)
        weebit_ts.append(ts)
    print '"' + str(file) + '",' + str(len(wr2_c.sents(fileids=file))) + ',' + str(TTR_tagged_sents(wr2_txt_ts)) + ',' + str(sent_length_average(wr2_txt_ts)) + ',' + str(word_length_average(wr2_txt_ts)) + ',' + str(count_pronouns_corpus(wr2_txt_ts))
print '"WRLevel2",' + str(len(wr2_c.sents())) + ',' + str(TTR_tagged_sents(wr2_ts)) + ',' + str(sent_length_average(wr2_ts)) + ',' + str(word_length_average(wr2_ts)) + ',' + str(count_pronouns_corpus(wr2_ts))
