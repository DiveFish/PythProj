'''
Created on 8 Mar 2016

@author: kibs
'''

#import os
import nltk
from nltk.corpus import nps_chat
#from nltk.corpus.reader.plaintext import PlaintextCorpusReader
from type_token_ratio import ttr_tagged_sents
from pronoun_count import count_pronouns_corpus
from sent_feats import sent_length_average, word_length_average
print '"File","No. of Sentences","1/TTR","Avg Sentence Length","Avg Word Length","Pronoun Count","OVERALL","TRADITIONAL","LEXICAL"'
#print '"nps_chat"'

whole_chat = list()
for file in nps_chat.fileids():
    #count = 0
    chat_tagged = list()
    for post in nps_chat.tagged_posts(file):
        if len(chat_tagged) > 99:
            continue
        chat_tagged.append(post)
        
    num_sents = len(chat_tagged)
    inverse_ttr = 1.0/ttr_tagged_sents(chat_tagged)
    sent_len = sent_length_average(chat_tagged)
    word_len = word_length_average(chat_tagged)
    prn_count = count_pronouns_corpus(chat_tagged)
    overall = (inverse_ttr+sent_len+word_len+prn_count)/4.0
    lexical = (inverse_ttr+prn_count)/2.0
    traditional = (word_len+sent_len)/2.0
    print '"' + str(file) + '",' + str(num_sents) + ',' + str(inverse_ttr) + ',' + str(sent_len) + ',' + str(word_len) + ',' + str(prn_count) + ',' + str(overall) + ',' + str(traditional) + ',' + str(lexical)
    #print '"' + str(file) + '",' + str(len(nps_chat.tagged_posts(fileids=file))) + ',' + str(TTR_tagged_sents(chat_tagged)) + ',' + str(sent_length_average(chat_tagged)) + ',' + str(word_length_average(chat_tagged)) + ',' + str(count_pronouns_per_words(chat_tagged))
#print '"nps_chat Concat",' + str(len(nps_chat.posts())) + ',' + str(ttr_tagged_sents(whole_chat)) + ',' + str(sent_length_average(whole_chat)) + ',' + str(word_length_average(whole_chat)) + ',' + str(count_pronouns_per_words(whole_chat))