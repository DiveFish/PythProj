"""
Created on 9 March 2016
@author: ankita
"""

from collections import Counter
import nltk
import os
import sys
import ntpath
from nltk.corpus import PlaintextCorpusReader


def read_input(path):
    if os.path.isfile(path):
        read_file(path)
    else:
        read_dir(path)


def read_file(path):
    corpus_root = os.getcwd()
    file = PlaintextCorpusReader(corpus_root, path)
    tagged_file = list()
    for sent in file.sents():
        tagged_sent = nltk.pos_tag(sent)
        tagged_file.append(tagged_sent)
    return tagged_file



def read_dir(path):

    #newpath is the path where the folder for the output files is created
    newpath = path
    if not os.path.exists(newpath):
        os.makedirs(newpath)

    os.chdir(r"C:\Users\Ankita\Desktop\WS 2015_16\Python\Project\Proj\InputFiles")

    for file in os.listdir("C:\Users\Ankita\Desktop\WS 2015_16\Python\Project\Proj\InputFiles"):
        if file.endswith(".txt"):
            f = open(file, "r")
            y = "parsed_" + os.path.basename(f.name)

            filename = open(os.path.join(newpath,y) ,'w')
            sys.stdout = filename
            line = f.readline()
            while line:
                text = nltk.word_tokenize(line)
                print text
                tags = nltk.pos_tag(text)
                print tags
                counts = Counter(tag for word,tag in tags)
                print counts
                print '\n'
                line = f.readline()
            f.close()
