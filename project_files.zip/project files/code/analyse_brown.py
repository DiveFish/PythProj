'''
Created on 8 Mar 2016

@author: kibs
'''

#import os
import nltk
from nltk.corpus import brown
#from nltk.corpus.reader.plaintext import PlaintextCorpusReader
from type_token_ratio import ttr_tagged_sents
from pronoun_count import count_pronouns_per_words, count_pronouns_corpus
from sent_feats import sent_length_average, word_length_average
print '"File","No. of Sentences","1/TTR","Avg Sentence Length","Avg Word Length","Pronoun Count","OVERALL","TRADITIONAL","LEXICAL"'

for cat in ['news','government','editorial','reviews']:
    #print str(cat)
    index = 1
    whole_news = list()
    for file in brown.fileids(cat):
        if index > 15:
            continue
        news_tagged = list()
        for sent in brown.tagged_sents(fileids=file):
            news_tagged.append(sent)
            whole_news.append(sent)
        num_sents = len(news_tagged)
        inverse_ttr = 1.0/ttr_tagged_sents(news_tagged)
        sent_len = sent_length_average(news_tagged)
        word_len = word_length_average(news_tagged)
        prn_count = count_pronouns_corpus(news_tagged)
        overall = (inverse_ttr+sent_len+word_len+prn_count)/4.0
        lexical = (inverse_ttr+prn_count)/2.0
        traditional = (word_len+sent_len)/2.0
        print '"' + str(cat) + ' ' + str(file) + '",' + str(num_sents) + ',' + str(inverse_ttr) + ',' + str(sent_len) + ',' + str(word_len) + ',' + str(prn_count) + ',' + str(overall) + ',' + str(traditional) + ',' + str(lexical)
        index += 1
    #print '"Brown ' + str(cat) + ' Concat",' + str(len(whole_news)) + ',' + str(ttr_tagged_sents(whole_news)) + ',' + str(sent_length_average(whole_news)) + ',' + str(word_length_average(whole_news)) + ',' + str(count_pronouns_corpus(whole_news))