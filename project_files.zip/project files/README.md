# Complexity Analysis
Some simple steps to get to know the functionalities of the complexity analysis program (it is assumed that nltk_data has been downloaded):

1. Run the gui!
2. << To get 5 random sentences of a certain level and register, select a level and a register.
3. Want to print the sentences to the screen? Just press the "print to screen"-button!
4. Want to save the sentences to a file? Enter a filename into the textfield and press the "save to file"-button.
5. << To have the analysis tool run over a raw, untagged textfile, enter the COMPLETE file directory into the textfield.
6. ! Note that the file has to be in the current working directory of the Python IDE.
7. Want to print the results of the analysis to the screen? Just press the "print to screen"-button!
8. Want to save the results of the analysis to a file? Enter a filename into the textfield and press the "save to file"-button.
