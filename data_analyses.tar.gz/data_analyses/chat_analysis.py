"""
Created on 05 March 2016
@author pat
"""
from nltk.corpus import nps_chat

from nps_tags import nps_chat_tagged
from pronoun_count import count_pronouns_per_sentence
from sent_feats import sent_length_average, word_length_average
from type_token_ratio import ttr_tagged_sents

wr = open("Chat_analysis_pronouns_per_sentence.txt", "w")
"""




"""
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="10-19-20s_706posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="10-19-40s_686posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="11-08-40s_706posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="11-06-adults_706posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="10-26-teens_706posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="11-09-teens_706posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="10-19-adults_706posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="11-09-20s_706posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="11-08-adults_705posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="11-08-teens_706posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="11-09-adults_706posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="10-19-30s_705posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="11-08-20s_705posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="11-09-40s_706posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat.tagged_posts(fileids="10-24-40s_706posts.xml")))+"\n")
wr.write(str(count_pronouns_per_sentence(nps_chat_tagged))+"\n")



"""
wr.write("Type-token ratio "+str(ttr_tagged_sents(nps_chat_tagged))+"\n")
wr.write("Average word length "+str(word_length_average(nps_chat_tagged))+"\n")
wr.write("Average sentence length: "+str(sent_length_average(nps_chat_tagged))+"\n")
"""
