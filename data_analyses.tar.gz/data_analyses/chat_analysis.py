"""
Created on 05 March 2016
@author pat
"""

from nps_tags import nps_chat_tagged
from pronoun_count import count_pronouns_corpus, count_pronouns_per_words
from sent_feats import sent_length_average, word_length_average
from type_token_ratio import ttr_tagged_sents

wr = open("Chat_analysis_pronoun_ratio.txt", "w")
wr.write("Type-token ratio "+str(ttr_tagged_sents(nps_chat_tagged))+"\n")
wr.write("Average word length "+str(word_length_average(nps_chat_tagged))+"\n")
wr.write("Average sentence length: "+str(sent_length_average(nps_chat_tagged))+"\n")
wr.write("Number of pronouns per sentence "+str(count_pronouns_corpus(nps_chat_tagged))+"\n")
wr.write("Ratio of pronouns per total number of words "+str(count_pronouns_per_words(nps_chat_tagged))+"\n")