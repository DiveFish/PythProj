'''
Created on 22 Jan 2016
Updated on 20 Feb 2016
@author: kibs
'''

import nltk
from nltk.corpus import brown

# 1 ca16    news
# 2 cb02    editorial
# 3 cc17    reviews

news_words = brown.words(fileids="ca16")
news_tagged = nltk.pos_tag(news_words)
print news_tagged

'''
news_sents = brown.sents(fileids="ca16")
print nltk.pos_tag(news_sents)
ERROR
nltk.pos_tag() takes list of words
news_sents is a list of list of words/list of sentences
'''

news_tagged_sents = brown.tagged_sents(fileids="ca16")

editorial_tagged_sents = brown.tagged_sents(fileids="cb02")

review_tagged_sents = brown.tagged_sents(fileids="cc17")