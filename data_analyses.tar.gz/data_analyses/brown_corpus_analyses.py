"""
Created on 05 March 2016
@author pat
"""

"""
ca: news, ID A01-44
cb: editorial, ID B01-27
cc: reviews, ID C01-17
ch: government, ID H01-30
"""

import os
from nltk.corpus import brown
from pronoun_count import count_pronouns_corpus, count_pronouns_per_words
from sent_feats import sent_length_average, word_length_average
from type_token_ratio import ttr_tagged_sents

wr = open("Complexity_lexical_pronoun_ratio.txt","w")


def analysis(corpus):
    """
def analysis(corpus, register, fileNumber):

    wr = open(str("brown"+str(register)+str(fileNumber)+".txt"), "w")
    wr.write("brown"+str(register)+str(fileNumber) + str(ttr_tagged_sents(corpus))+"\n")
    wr.write(str(word_length_average(corpus))+"\n")
    wr.write(str(sent_length_average(corpus))+"\n")
    wr.write(str(count_pronouns_corpus(corpus))+"\n")
    wr.write(str(count_pronouns_per_words(corpus))+"\n")
    """
    ttr = ttr_tagged_sents(corpus)
    sent = sent_length_average(corpus)
    word = word_length_average(corpus)
    pron_words = count_pronouns_per_words(corpus)
    # pron=count_pronouns_corpus(corpus)

    # overall_average = (ttr+sent+word+pron_words)/4
    # wr.write(str(overall_average)+"\n")
    lexical = (ttr+pron_words)/2
    wr.write(str(lexical)+"\n")
    # traditional = (sent+word)/2
    # wr.write(str(traditional)+"\n")


analysis(brown.tagged_sents(fileids="ca01"), "_news_", "01")
analysis(brown.tagged_sents(fileids="ca02"), "_news_", "02")
analysis(brown.tagged_sents(fileids="ca03"), "_news_", "03")
analysis(brown.tagged_sents(fileids="ca04"), "_news_", "04")
analysis(brown.tagged_sents(fileids="ca05"), "_news_", "05")
analysis(brown.tagged_sents(fileids="ca06"), "_news_", "06")
analysis(brown.tagged_sents(fileids="ca07"), "_news_", "07")
analysis(brown.tagged_sents(fileids="ca08"), "_news_", "08")
analysis(brown.tagged_sents(fileids="ca09"), "_news_", "09")

i=10
while i < 45:
    analysis(brown.tagged_sents(fileids=("ca"+str(i))), "_news_", i)
    i += 1


analysis(brown.tagged_sents(fileids="cb01"), "_editorial_", "01")
analysis(brown.tagged_sents(fileids="cb02"), "_editorial_", "02")
analysis(brown.tagged_sents(fileids="cb03"), "_editorial_", "03")
analysis(brown.tagged_sents(fileids="cb04"), "_editorial_", "04")
analysis(brown.tagged_sents(fileids="cb05"), "_editorial_", "05")
analysis(brown.tagged_sents(fileids="cb06"), "_editorial_", "06")
analysis(brown.tagged_sents(fileids="cb07"), "_editorial_", "07")
analysis(brown.tagged_sents(fileids="cb08"), "_editorial_", "08")
analysis(brown.tagged_sents(fileids="cb09"), "_editorial_", "09")

i=10
while i < 28:
    analysis(brown.tagged_sents(fileids=("cb"+str(i))), "_editorial_", i)
    i += 1


analysis(brown.tagged_sents(fileids="cc01"), "_reviews_", "01")
analysis(brown.tagged_sents(fileids="cc02"), "_reviews_", "02")
analysis(brown.tagged_sents(fileids="cc03"), "_reviews_", "03")
analysis(brown.tagged_sents(fileids="cc04"), "_reviews_", "04")
analysis(brown.tagged_sents(fileids="cc05"), "_reviews_", "05")
analysis(brown.tagged_sents(fileids="cc06"), "_reviews_", "06")
analysis(brown.tagged_sents(fileids="cc07"), "_reviews_", "07")
analysis(brown.tagged_sents(fileids="cc08"), "_reviews_", "08")
analysis(brown.tagged_sents(fileids="cc09"), "_reviews_", "09")

i=10
while i < 18:
    analysis(brown.tagged_sents(fileids=("cc"+str(i))), "_reviews_", i)
    i += 1


analysis(brown.tagged_sents(fileids="ch01"), "_government_", "01")
analysis(brown.tagged_sents(fileids="ch02"), "_government_", "02")
analysis(brown.tagged_sents(fileids="ch03"), "_government_", "03")
analysis(brown.tagged_sents(fileids="ch04"), "_government_", "04")
analysis(brown.tagged_sents(fileids="ch05"), "_government_", "05")
analysis(brown.tagged_sents(fileids="ch06"), "_government_", "06")
analysis(brown.tagged_sents(fileids="ch07"), "_government_", "07")
analysis(brown.tagged_sents(fileids="ch08"), "_government_", "08")
analysis(brown.tagged_sents(fileids="ch09"), "_government_", "09")

i=10
while i < 31:
    analysis(brown.tagged_sents(fileids=("ch"+str(i))), "_government_", i)
    i += 1

wr = open(str("Filenames.txt"), "w")
for file in os.listdir("/home/patricia/PycharmProjects/data_analyses"):
    wr.write(file+"\n")